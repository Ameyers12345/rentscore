import clsx, { ClassValue } from 'clsx';

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function scoreTone(score: number) {
  if (score >= 85) return 'text-success';
  if (score >= 70) return 'text-brand';
  if (score >= 55) return 'text-warning';
  return 'text-danger';
}
