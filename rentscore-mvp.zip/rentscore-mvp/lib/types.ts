export type Review = {
  id: string;
  reviewerName: string;
  reviewerRole: 'tenant' | 'landlord';
  targetName: string;
  targetType: 'tenant' | 'landlord' | 'property';
  rating: number;
  text: string;
  verified: boolean;
  createdAt: string;
};

export type MaintenanceTicket = {
  id: string;
  title: string;
  property: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'Scheduled' | 'In progress' | 'Resolved';
  dueDate: string;
  raisedBy: string;
};

export type PropertyProfile = {
  id: string;
  address: string;
  city: string;
  postcode: string;
  landlord: string;
  score: number;
  occupancy: string;
  inventoryItems: number;
  maintenanceSla: string;
  description: string;
};
