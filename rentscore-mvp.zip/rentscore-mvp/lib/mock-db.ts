import { MaintenanceTicket, PropertyProfile, Review } from '@/lib/types';

export const tenantPassport = {
  name: 'Emma Patel',
  role: 'Professional tenant',
  rentScore: 82,
  idVerified: true,
  livenessVerified: true,
  affordability: 'Strong',
  behaviour: 'Excellent',
  risk: 'Low',
  rentHistoryMonths: 24,
  employer: 'Product Designer · Remote',
  shareLink: 'https://rentscore.example/passports/emma-patel',
  checks: [
    'Identity verified',
    'Facial liveness complete',
    'Income evidence uploaded',
    'PEP / sanctions clear',
    'Previous landlord reference verified',
  ],
};

export const landlordProfile = {
  id: 'verified-landlord-lucas-bennett',
  name: 'Lucas Bennett',
  badge: 'Verified Landlord',
  portfolioCount: 8,
  averageScore: 4.7,
  compliance: ['AML checked', 'Address ownership evidence uploaded', 'Deposit handling policy verified'],
  responseTime: '1.8 hours average',
  rentGuarantee: true,
};

export const propertyProfiles: PropertyProfile[] = [
  {
    id: 'camden-flat-12',
    address: '12 Delancey Street',
    city: 'London',
    postcode: 'NW1 7NH',
    landlord: 'Lucas Bennett',
    score: 91,
    occupancy: 'Tenanted',
    inventoryItems: 47,
    maintenanceSla: 'Urgent issues within 4 hours',
    description: 'Two-bed flat with verified inventory, gas safety, EPC and appliance history stored in one place.',
  },
  {
    id: 'salford-terrace-9',
    address: '9 Riverside Terrace',
    city: 'Salford',
    postcode: 'M3 5FA',
    landlord: 'Priya Shah',
    score: 87,
    occupancy: 'Available from April',
    inventoryItems: 31,
    maintenanceSla: 'Next-day response for medium issues',
    description: 'Family terrace with digital inventory, tenant communications, and repair timeline visibility.',
  },
];

export const reviews: Review[] = [
  {
    id: 'r1',
    reviewerName: 'Emma Patel',
    reviewerRole: 'tenant',
    targetName: 'Lucas Bennett',
    targetType: 'landlord',
    rating: 5,
    text: 'Fast on repairs, clear on deposit deductions, and every document was shared upfront.',
    verified: true,
    createdAt: '2026-03-11',
  },
  {
    id: 'r2',
    reviewerName: 'Lucas Bennett',
    reviewerRole: 'landlord',
    targetName: 'Emma Patel',
    targetType: 'tenant',
    rating: 5,
    text: 'Paid on time, kept the flat immaculate and handled inspections professionally.',
    verified: true,
    createdAt: '2026-03-09',
  },
  {
    id: 'r3',
    reviewerName: 'Noah Clarke',
    reviewerRole: 'tenant',
    targetName: '12 Delancey Street',
    targetType: 'property',
    rating: 4,
    text: 'Well maintained and inventory matched move-in condition. Only issue was broadband setup delay.',
    verified: true,
    createdAt: '2026-03-02',
  },
];

export const maintenanceTickets: MaintenanceTicket[] = [
  {
    id: 'm1',
    title: 'Boiler pressure dropping',
    property: '12 Delancey Street',
    severity: 'High',
    status: 'Scheduled',
    dueDate: '2026-03-20',
    raisedBy: 'Emma Patel',
  },
  {
    id: 'm2',
    title: 'Window latch in second bedroom',
    property: '12 Delancey Street',
    severity: 'Medium',
    status: 'In progress',
    dueDate: '2026-03-19',
    raisedBy: 'Emma Patel',
  },
  {
    id: 'm3',
    title: 'Hallway light sensor flickering',
    property: '9 Riverside Terrace',
    severity: 'Low',
    status: 'Open',
    dueDate: '2026-03-24',
    raisedBy: 'Ava Johnson',
  },
];
