import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        ink: '#08111f',
        panel: '#0d1728',
        panelSoft: '#13233d',
        brand: '#57e2ff',
        brand2: '#7d88ff',
        success: '#6ee7b7',
        warning: '#fbbf24',
        danger: '#fb7185',
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(87,226,255,0.12), 0 16px 50px rgba(8,17,31,0.35)',
      },
      backgroundImage: {
        'grid-fade': 'radial-gradient(circle at top, rgba(87,226,255,0.14), transparent 32%), linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px)',
      },
      backgroundSize: {
        'grid-size': '100% 100%, 32px 32px, 32px 32px',
      },
    },
  },
  plugins: [],
};

export default config;
