import { ReactNode } from 'react';

export function SectionShell({ title, eyebrow, description, children }: { title: string; eyebrow: string; description: string; children: ReactNode }) {
  return (
    <section className="mx-auto max-w-7xl px-6 py-14">
      <div className="max-w-3xl">
        <div className="badge">{eyebrow}</div>
        <h2 className="mt-5 text-4xl font-black tracking-tight text-white">{title}</h2>
        <p className="mt-4 text-lg text-white/65">{description}</p>
      </div>
      <div className="mt-8">{children}</div>
    </section>
  );
}
