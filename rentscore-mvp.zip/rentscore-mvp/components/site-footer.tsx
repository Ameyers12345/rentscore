export function SiteFooter() {
  return (
    <footer className="border-t border-white/10">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-6 py-10 text-sm text-white/55 md:flex-row md:items-center md:justify-between">
        <div>© 2026 RentScore™ · Trust ecosystem for the UK rental market.</div>
        <div>Netlify-ready Next.js MVP · Supabase or Firebase can replace mock storage.</div>
      </div>
    </footer>
  );
}
