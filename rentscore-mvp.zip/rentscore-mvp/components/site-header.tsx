import Link from 'next/link';
import { ShieldCheck } from 'lucide-react';

const nav = [
  { href: '/tenant/passport', label: 'Tenant passport' },
  { href: '/landlords/verified-landlord-lucas-bennett', label: 'Verified landlords' },
  { href: '/reviews', label: 'Mutual reviews' },
  { href: '/properties/camden-flat-12', label: 'Property profiles' },
  { href: '/agreements', label: 'AI agreements' },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-ink/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-3 text-white">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand/15 text-brand">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <div className="text-lg font-bold">RentScore™</div>
            <div className="text-xs uppercase tracking-[0.24em] text-white/50">Trust starts with your RentScore</div>
          </div>
        </Link>
        <nav className="hidden items-center gap-6 lg:flex">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm text-white/70 transition hover:text-white">
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="button-secondary hidden sm:inline-flex">Dashboard</Link>
          <Link href="/signup" className="button-primary">Join beta</Link>
        </div>
      </div>
    </header>
  );
}
