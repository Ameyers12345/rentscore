export function PageHero({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <section className="border-b border-white/10 bg-white/[0.02]">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="badge">{eyebrow}</div>
        <h1 className="mt-5 text-4xl font-black tracking-tight text-white md:text-5xl">{title}</h1>
        <p className="mt-4 max-w-3xl text-lg text-white/65">{description}</p>
      </div>
    </section>
  );
}
