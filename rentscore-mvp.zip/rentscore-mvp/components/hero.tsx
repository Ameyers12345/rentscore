import Link from 'next/link';
import { ArrowRight, BadgeCheck, Building2, FileText, Star, Wrench } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-white/10">
      <div className="absolute inset-0 bg-grid-fade bg-grid-size opacity-60" />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-6 py-20 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
        <div>
          <div className="badge mb-6">Portable trust profiles · verified reviews · property ops</div>
          <h1 className="max-w-3xl text-5xl font-black leading-tight tracking-tight text-white md:text-6xl">
            Build a trusted rental identity before the application starts.
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-white/70">
            RentScore combines a tenant Trust Passport, verified landlord profiles, mutual reviews, property operations,
            maintenance tracking, AI-built agreements, and rent protection tools in one Netlify-ready MVP.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link href="/signup" className="button-primary">
              Join early access <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
            <Link href="/dashboard" className="button-secondary">Open product demo</Link>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[
              { icon: BadgeCheck, title: 'Trust Passport', text: 'ID, liveness, income and sanctions status' },
              { icon: Star, title: 'Mutual reviews', text: 'Verified tenant, landlord and property feedback' },
              { icon: Wrench, title: 'Maintenance', text: 'Fault logging, SLAs and status tracking' },
              { icon: FileText, title: 'AI agreements', text: 'Periodic tenancy templates and exports' },
            ].map((item) => (
              <div key={item.title} className="rounded-3xl border border-white/10 bg-white/5 p-4">
                <item.icon className="h-5 w-5 text-brand" />
                <div className="mt-3 font-semibold text-white">{item.title}</div>
                <div className="mt-1 text-sm text-white/55">{item.text}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-7">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm uppercase tracking-[0.2em] text-brand">Live preview</div>
              <div className="mt-2 text-2xl font-bold text-white">Tenant Trust Passport</div>
            </div>
            <div className="rounded-2xl border border-success/20 bg-success/10 px-4 py-2 text-success">Ready to rent</div>
          </div>
          <div className="mt-8 rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-3xl font-bold text-white">Emma Patel</div>
                <div className="mt-1 text-sm text-white/55">Professional tenant · London</div>
              </div>
              <div className="rounded-3xl bg-brand px-5 py-4 text-right text-ink">
                <div className="text-xs font-bold uppercase tracking-[0.24em]">RentScore</div>
                <div className="text-4xl font-black">82</div>
              </div>
            </div>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <Signal label="Identity" value="Verified" />
              <Signal label="Affordability" value="Strong" />
              <Signal label="Behaviour" value="Excellent" />
              <Signal label="Risk" value="Low" />
            </div>
            <div className="mt-6 grid gap-3 text-sm text-white/70">
              <Meta text="ID & income verified" />
              <Meta text="24 months on-time rent payments" />
              <Meta text="Positive landlord references" />
              <Meta text="Portable PDF & share link ready" />
            </div>
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <MiniStat icon={Building2} label="Verified landlords" value="126" />
            <MiniStat icon={Star} label="Seed reviews" value="341" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Signal({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-ink/50 p-4">
      <div className="text-xs uppercase tracking-[0.2em] text-white/45">{label}</div>
      <div className="mt-1 text-lg font-semibold text-white">{value}</div>
    </div>
  );
}

function Meta({ text }: { text: string }) {
  return <div className="rounded-2xl border border-white/10 bg-ink/40 px-4 py-3">{text}</div>;
}

function MiniStat({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <Icon className="h-5 w-5 text-brand" />
      <div className="mt-3 text-sm text-white/55">{label}</div>
      <div className="text-2xl font-bold text-white">{value}</div>
    </div>
  );
}
