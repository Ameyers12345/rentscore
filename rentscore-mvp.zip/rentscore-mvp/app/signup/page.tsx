import { PageHero } from '@/components/page-hero';

export default function SignupPage() {
  return (
    <>
      <PageHero
        eyebrow="Early access"
        title="Join the RentScore beta"
        description="Waitlist and role-based onboarding for tenants, landlords and agents. Wire this form to Supabase auth or your existing Netlify forms backend."
      />
      <section className="mx-auto max-w-3xl px-6 py-10">
        <div className="card p-6">
          <form className="grid gap-4">
            <div className="grid gap-4 md:grid-cols-2">
              <input className="input" placeholder="First name" />
              <input className="input" placeholder="Last name" />
            </div>
            <input className="input" placeholder="Email address" />
            <select className="input default:bg-ink">
              <option>Tenant</option>
              <option>Landlord</option>
              <option>Agent</option>
            </select>
            <textarea className="input min-h-32" placeholder="Tell us what you want to use RentScore for" />
            <button type="button" className="button-primary">Request early access</button>
          </form>
        </div>
      </section>
    </>
  );
}
