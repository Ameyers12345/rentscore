import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PageHero } from '@/components/page-hero';
import { propertyProfiles } from '@/lib/mock-db';

export default function PropertyProfilePage({ params }: { params: { id: string } }) {
  const property = propertyProfiles.find((item) => item.id === params.id);
  if (!property) notFound();

  return (
    <>
      <PageHero
        eyebrow="Property profile"
        title={property.address}
        description="Property trust page combining score, inventory, occupancy, landlord accountability and maintenance workflows."
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-6 py-10 xl:grid-cols-[0.95fr_1.05fr]">
        <div className="space-y-6">
          <div className="card p-7">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-3xl font-bold text-white">{property.address}</div>
                <div className="mt-2 text-white/55">{property.city} · {property.postcode}</div>
              </div>
              <div className="rounded-3xl bg-brand px-5 py-4 text-ink">
                <div className="text-xs font-black uppercase tracking-[0.2em]">Property score</div>
                <div className="text-4xl font-black">{property.score}</div>
              </div>
            </div>
            <p className="mt-6 text-white/70">{property.description}</p>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <Meta label="Landlord" value={property.landlord} />
              <Meta label="Occupancy" value={property.occupancy} />
              <Meta label="Inventory items" value={String(property.inventoryItems)} />
              <Meta label="Maintenance SLA" value={property.maintenanceSla} />
            </div>
          </div>
          <div className="card p-6">
            <h2 className="text-2xl font-bold text-white">Inventory summary</h2>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {['Kitchen appliances photographed', 'Meter readings stored', 'Wall condition check', 'Bathroom fixtures logged', 'Fire safety pack', 'Move-in signature pending'].map((item) => (
                <div key={item} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-white/80">{item}</div>
              ))}
            </div>
          </div>
        </div>
        <div className="space-y-6">
          <div className="card p-6">
            <h2 className="text-2xl font-bold text-white">Actions</h2>
            <div className="mt-5 grid gap-4">
              <Link href={`/properties/${property.id}/maintenance`} className="button-primary">Open maintenance tracking</Link>
              <Link href="/agreements" className="button-secondary">Generate tenancy agreement</Link>
              <Link href="/insurance" className="button-secondary">View rent guarantee options</Link>
            </div>
          </div>
          <div className="card p-6">
            <h2 className="text-2xl font-bold text-white">Compliance vault</h2>
            <div className="mt-5 space-y-3">
              {['EPC certificate attached', 'Gas safety due in 78 days', 'Deposit rules visible to tenant', 'Repair history timeline stored'].map((item) => (
                <div key={item} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-white/80">{item}</div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="text-xs uppercase tracking-[0.2em] text-white/45">{label}</div>
      <div className="mt-1 font-semibold text-white">{value}</div>
    </div>
  );
}
