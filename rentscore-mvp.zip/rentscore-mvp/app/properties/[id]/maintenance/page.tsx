import { notFound } from 'next/navigation';
import { PageHero } from '@/components/page-hero';
import { maintenanceTickets, propertyProfiles } from '@/lib/mock-db';

export default function MaintenancePage({ params }: { params: { id: string } }) {
  const property = propertyProfiles.find((item) => item.id === params.id);
  if (!property) notFound();
  const tickets = maintenanceTickets.filter((item) => item.property === property.address);

  return (
    <>
      <PageHero
        eyebrow="Maintenance workspace"
        title={`Maintenance for ${property.address}`}
        description="Tenants can report faults with photos and urgency. Landlords can acknowledge, assign and close issues with SLA visibility."
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-6 py-10 xl:grid-cols-[0.85fr_1.15fr]">
        <div className="card p-6">
          <h2 className="text-2xl font-bold text-white">Raise a maintenance issue</h2>
          <form className="mt-5 space-y-4">
            <input className="input" placeholder="Issue title" />
            <select className="input default:bg-ink">
              <option>Critical</option>
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
            <textarea className="input min-h-36" placeholder="Describe the issue, what you've tried, and any safety impact" />
            <input className="input" placeholder="Photo upload field can be wired to Supabase storage" />
            <button type="button" className="button-primary">Submit ticket</button>
          </form>
        </div>
        <div className="space-y-4">
          {tickets.map((ticket) => (
            <div key={ticket.id} className="card p-6">
              <div className="flex flex-wrap items-center gap-3 text-sm text-white/55">
                <span className="badge">{ticket.severity}</span>
                <span>{ticket.status}</span>
                <span>Due {ticket.dueDate}</span>
              </div>
              <h2 className="mt-4 text-2xl font-bold text-white">{ticket.title}</h2>
              <p className="mt-2 text-white/60">Raised by {ticket.raisedBy} · SLA target driven by property settings</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
