import Link from 'next/link';
import { PageHero } from '@/components/page-hero';
import { landlordProfile, maintenanceTickets, propertyProfiles, reviews, tenantPassport } from '@/lib/mock-db';

export default function DashboardPage() {
  return (
    <>
      <PageHero
        eyebrow="Product demo"
        title="RentScore operating dashboard"
        description="A founder-ready MVP home for monitoring signups, trust activity, reviews, repairs, agreements and monetisation pathways."
      />
      <section className="mx-auto max-w-7xl px-6 py-10">
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          <Stat label="Tenant RentScore" value={String(tenantPassport.rentScore)} helper="Emma Patel demo passport" />
          <Stat label="Landlord profile score" value={String(landlordProfile.averageScore)} helper="Average verified rating" />
          <Stat label="Live reviews" value={String(reviews.length)} helper="Verified feedback items" />
          <Stat label="Open maintenance tickets" value={String(maintenanceTickets.length)} helper="Across seeded properties" />
        </div>

        <div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="card p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-white">Launch surfaces</h2>
              <div className="text-sm text-white/45">Clickable product pages</div>
            </div>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {[
                ['/tenant/passport', 'Tenant Trust Passport'],
                ['/landlords/verified-landlord-lucas-bennett', 'Verified landlord profile'],
                ['/reviews', 'Mutual reviews'],
                ['/properties/camden-flat-12', 'Property profile'],
                ['/properties/camden-flat-12/maintenance', 'Maintenance workspace'],
                ['/agreements', 'AI agreements'],
                ['/insurance', 'Insurance & rent guarantee'],
                ['/signup', 'Signup / waitlist'],
              ].map(([href, label]) => (
                <Link key={href} href={href} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-white/85 transition hover:bg-white/10">
                  {label}
                </Link>
              ))}
            </div>
          </div>

          <div className="card p-6">
            <h2 className="text-2xl font-bold text-white">Property pipeline</h2>
            <div className="mt-5 space-y-4">
              {propertyProfiles.map((property) => (
                <div key={property.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="font-semibold text-white">{property.address}</div>
                      <div className="text-sm text-white/50">{property.city} · {property.postcode}</div>
                    </div>
                    <div className="rounded-2xl bg-brand/15 px-3 py-2 text-brand">Score {property.score}</div>
                  </div>
                  <div className="mt-3 text-sm text-white/60">{property.description}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Stat({ label, value, helper }: { label: string; value: string; helper: string }) {
  return (
    <div className="card p-5">
      <div className="text-sm uppercase tracking-[0.2em] text-white/45">{label}</div>
      <div className="mt-3 text-4xl font-black text-white">{value}</div>
      <div className="mt-2 text-sm text-white/55">{helper}</div>
    </div>
  );
}
