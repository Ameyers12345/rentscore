import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  return NextResponse.json({
    ok: true,
    received: body,
    draft: 'This is where you would call OpenAI or Anthropic with your tenancy template, legal prompt guardrails and export pipeline.',
  });
}
