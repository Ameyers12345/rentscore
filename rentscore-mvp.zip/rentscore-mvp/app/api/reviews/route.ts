import { NextResponse } from 'next/server';
import { reviews } from '@/lib/mock-db';

export async function GET() {
  return NextResponse.json({ ok: true, data: reviews });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  return NextResponse.json({ ok: true, received: body, message: 'Persist submitted reviews in Supabase and route to moderation.' });
}
