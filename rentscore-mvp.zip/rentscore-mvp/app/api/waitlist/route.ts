import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  return NextResponse.json({ ok: true, received: body, message: 'Connect this to Supabase or Netlify Forms for persistence.' });
}
