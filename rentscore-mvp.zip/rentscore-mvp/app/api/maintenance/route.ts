import { NextResponse } from 'next/server';
import { maintenanceTickets } from '@/lib/mock-db';

export async function GET() {
  return NextResponse.json({ ok: true, data: maintenanceTickets });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  return NextResponse.json({ ok: true, received: body, message: 'Persist maintenance tickets and file uploads via Supabase storage.' });
}
