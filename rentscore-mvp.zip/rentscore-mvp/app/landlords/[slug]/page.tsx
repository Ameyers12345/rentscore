import { PageHero } from '@/components/page-hero';
import { landlordProfile, propertyProfiles } from '@/lib/mock-db';

export default function LandlordProfilePage() {
  return (
    <>
      <PageHero
        eyebrow="Verified landlord"
        title="Landlord profile"
        description="A trust-first landlord page that shows professionalism, response standards, compliance and portfolio quality before a tenant even books a viewing."
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-6 py-10 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="card p-7">
          <div className="badge">{landlordProfile.badge}</div>
          <h2 className="mt-5 text-3xl font-bold text-white">{landlordProfile.name}</h2>
          <div className="mt-3 flex flex-wrap gap-3">
            <Pill label={`${landlordProfile.portfolioCount} active units`} />
            <Pill label={`${landlordProfile.averageScore}/5 average`} />
            <Pill label={landlordProfile.responseTime} />
          </div>
          <div className="mt-6 rounded-3xl border border-brand/15 bg-brand/10 p-5 text-white/80">
            Rent guarantee eligible: <span className="font-semibold text-white">{landlordProfile.rentGuarantee ? 'Yes' : 'Not yet'}</span>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card p-6">
            <h3 className="text-2xl font-bold text-white">Compliance stack</h3>
            <div className="mt-5 space-y-3">
              {landlordProfile.compliance.map((item) => (
                <div key={item} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-white/80">{item}</div>
              ))}
            </div>
          </div>
          <div className="card p-6">
            <h3 className="text-2xl font-bold text-white">Portfolio snapshot</h3>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {propertyProfiles.map((property) => (
                <div key={property.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="font-semibold text-white">{property.address}</div>
                  <div className="mt-1 text-sm text-white/55">{property.city} · {property.postcode}</div>
                  <div className="mt-4 flex items-center justify-between text-sm">
                    <span className="text-white/55">Property score</span>
                    <span className="text-brand">{property.score}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Pill({ label }: { label: string }) {
  return <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/75">{label}</div>;
}
