import './globals.css';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'RentScore™ MVP',
  description: 'Netlify-ready MVP for tenant trust, landlord verification, property operations and AI agreements.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
