import { PageHero } from '@/components/page-hero';

export default function InsurancePage() {
  return (
    <>
      <PageHero
        eyebrow="Monetisation"
        title="Insurance, rent guarantee and premium landlord tools"
        description="A conversion page for paid landlord features such as rent guarantee cover, legal expenses, enhanced checks and faster maintenance workflows."
      />
      <section className="mx-auto max-w-7xl px-6 py-10">
        <div className="grid gap-6 lg:grid-cols-3">
          {[
            {
              title: 'Rent guarantee',
              price: '£9 / property / month',
              text: 'Protect against arrears risk with underwriting based on Trust Passport, affordability and verified rent history.',
            },
            {
              title: 'Compliance bundle',
              price: '£19 / month',
              text: 'Store landlord documents, agreement versions, inventory evidence and reminders in one place.',
            },
            {
              title: 'Pro operations',
              price: '£29 / month',
              text: 'Add contractor workflows, maintenance SLAs, AI agreements and portfolio analytics for scaling landlords.',
            },
          ].map((plan) => (
            <div key={plan.title} className="card p-6">
              <div className="badge">Premium</div>
              <h2 className="mt-4 text-2xl font-bold text-white">{plan.title}</h2>
              <div className="mt-3 text-3xl font-black text-brand">{plan.price}</div>
              <p className="mt-4 text-white/65">{plan.text}</p>
              <button className="button-primary mt-6 w-full">Request activation</button>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
