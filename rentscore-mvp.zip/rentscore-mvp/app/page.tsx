import Link from 'next/link';
import { Hero } from '@/components/hero';
import { SectionShell } from '@/components/section-shell';
import { ArrowRight, Building2, CheckCircle2, FileText, ShieldCheck, Star, Wrench } from 'lucide-react';

export default function HomePage() {
  return (
    <>
      <Hero />

      <SectionShell
        eyebrow="Core MVP"
        title="Everything you asked to see, wired into one branded product shell."
        description="This build includes the key launch modules: tenant trust passports, verified landlord profiles, mutual reviews, property profiles, maintenance tracking, AI agreements, and insurance / rent guarantee packaging."
      >
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {[
            {
              href: '/tenant/passport',
              icon: ShieldCheck,
              title: 'Tenant Trust Passport',
              text: 'Shareable trust identity with verification checks, affordability signals and score explanations.',
            },
            {
              href: '/landlords/verified-landlord-lucas-bennett',
              icon: Building2,
              title: 'Verified landlord profiles',
              text: 'Badge-led profiles with compliance evidence, response benchmarks and rent guarantee readiness.',
            },
            {
              href: '/reviews',
              icon: Star,
              title: 'Mutual reviews',
              text: 'Bidirectional reviews for tenants, landlords and properties with moderation-ready structure.',
            },
            {
              href: '/properties/camden-flat-12',
              icon: CheckCircle2,
              title: 'Property profiles',
              text: 'Inventory, documents, score, occupancy and landlord trust signals on one page.',
            },
            {
              href: '/properties/camden-flat-12/maintenance',
              icon: Wrench,
              title: 'Maintenance tracking',
              text: 'Fault reporting, SLA progress and landlord accountability from inside each property record.',
            },
            {
              href: '/agreements',
              icon: FileText,
              title: 'AI agreements',
              text: 'Prompt-guided tenancy agreement generator for post-Renters’ Rights Act periodic tenancies.',
            },
          ].map((item) => (
            <Link key={item.title} href={item.href} className="card group p-6 transition hover:-translate-y-1">
              <item.icon className="h-6 w-6 text-brand" />
              <h3 className="mt-5 text-2xl font-bold text-white">{item.title}</h3>
              <p className="mt-3 text-white/60">{item.text}</p>
              <div className="mt-5 inline-flex items-center text-sm font-semibold text-brand">
                Open page <ArrowRight className="ml-2 h-4 w-4 transition group-hover:translate-x-1" />
              </div>
            </Link>
          ))}
        </div>
      </SectionShell>

      <SectionShell
        eyebrow="Launch roadmap"
        title="Netlify deploy now, swap mock storage for real services next."
        description="The UI and route structure are production-shaped so a developer can move quickly from demo mode to a live MVP using Supabase, Onfido or Yoti, TrueLayer, Stripe, and moderation workflows."
      >
        <div className="grid gap-6 lg:grid-cols-3">
          {[
            ['Week 1', 'Ship branded product shell, auth, dashboards and seeded demo data.'],
            ['Week 2', 'Connect Supabase, waitlist capture, review submission, maintenance tickets.'],
            ['Week 3', 'Add verification integrations and PDF / share-link Trust Passport export.'],
            ['Week 4', 'Launch AI agreements, rent guarantee upsells and analytics events.'],
            ['Month 2', 'Bring landlord subscription billing and agent access controls online.'],
            ['Month 3', 'Add score engine, moderation queue, and Open Banking powered affordability.'],
          ].map(([phase, text]) => (
            <div key={phase} className="rounded-3xl border border-white/10 bg-white/5 p-5">
              <div className="text-sm font-semibold uppercase tracking-[0.22em] text-brand">{phase}</div>
              <p className="mt-3 text-white/70">{text}</p>
            </div>
          ))}
        </div>
      </SectionShell>
    </>
  );
}
