import { PageHero } from '@/components/page-hero';
import { tenantPassport } from '@/lib/mock-db';
import { scoreTone } from '@/lib/utils';

export default function TenantPassportPage() {
  return (
    <>
      <PageHero
        eyebrow="Tenant-first"
        title="Trust Passport"
        description="A reusable rental identity that packages verification, affordability and behaviour signals into one branded profile landlords can understand in seconds."
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-6 py-10 xl:grid-cols-[0.95fr_1.05fr]">
        <div className="card p-7">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="badge">Ready to rent</div>
              <h2 className="mt-5 text-3xl font-bold text-white">{tenantPassport.name}</h2>
              <p className="mt-1 text-white/55">{tenantPassport.role} · {tenantPassport.employer}</p>
            </div>
            <div className="rounded-[28px] bg-brand px-6 py-5 text-center text-ink">
              <div className="text-xs font-black uppercase tracking-[0.24em]">RentScore</div>
              <div className="text-5xl font-black">{tenantPassport.rentScore}</div>
            </div>
          </div>

          <div className="mt-7 grid gap-4 sm:grid-cols-2">
            <Info label="Identity" value={tenantPassport.idVerified ? 'Verified' : 'Pending'} />
            <Info label="Affordability" value={tenantPassport.affordability} />
            <Info label="Behaviour" value={tenantPassport.behaviour} />
            <Info label="Risk" value={tenantPassport.risk} tone={scoreTone(90)} />
          </div>

          <div className="mt-7 rounded-3xl border border-brand/15 bg-brand/10 p-5">
            <div className="text-sm uppercase tracking-[0.2em] text-brand">Shareable profile</div>
            <div className="mt-2 break-all text-white">{tenantPassport.shareLink}</div>
            <div className="mt-3 text-sm text-white/65">In production this page can export a PDF and signed share-link token.</div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card p-6">
            <h3 className="text-2xl font-bold text-white">Verification checks</h3>
            <div className="mt-5 space-y-3">
              {tenantPassport.checks.map((check) => (
                <div key={check} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-white/80">
                  {check}
                </div>
              ))}
            </div>
          </div>
          <div className="card p-6">
            <h3 className="text-2xl font-bold text-white">Score inputs</h3>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <ScoreItem label="Liveness complete" value="+10" />
              <ScoreItem label="Income evidence" value="+20" />
              <ScoreItem label="24 months rent history" value="+25" />
              <ScoreItem label="Positive reference" value="+12" />
              <ScoreItem label="Manual review confidence" value="+15" />
              <ScoreItem label="No sanctions match" value="+8" />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Info({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="text-xs uppercase tracking-[0.2em] text-white/45">{label}</div>
      <div className={`mt-1 text-lg font-semibold text-white ${tone ?? ''}`}>{value}</div>
    </div>
  );
}

function ScoreItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="text-sm text-white/55">{label}</div>
      <div className="mt-2 text-2xl font-bold text-brand">{value}</div>
    </div>
  );
}
