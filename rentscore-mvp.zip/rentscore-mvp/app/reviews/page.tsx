import { PageHero } from '@/components/page-hero';
import { reviews } from '@/lib/mock-db';

export default function ReviewsPage() {
  return (
    <>
      <PageHero
        eyebrow="Verified feedback"
        title="Mutual reviews"
        description="Tenants review landlords and properties. Landlords review tenants. Everything is verification-gated to keep the ecosystem credible."
      />
      <section className="mx-auto max-w-7xl px-6 py-10">
        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="card p-6">
            <h2 className="text-2xl font-bold text-white">Submit a review</h2>
            <form className="mt-5 space-y-4">
              <select className="input default:bg-ink">
                <option>Reviewing a landlord</option>
                <option>Reviewing a tenant</option>
                <option>Reviewing a property</option>
              </select>
              <input className="input" placeholder="Target name or property address" />
              <input className="input" placeholder="Rating (1-5)" />
              <textarea className="input min-h-36" placeholder="Share clear, factual feedback" />
              <button type="button" className="button-primary">Submit for moderation</button>
            </form>
          </div>

          <div className="space-y-4">
            {reviews.map((review) => (
              <article key={review.id} className="card p-6">
                <div className="flex flex-wrap items-center gap-3 text-sm text-white/55">
                  <span className="badge">{review.verified ? 'Verified review' : 'Pending'}</span>
                  <span>{review.reviewerRole} → {review.targetType}</span>
                  <span>{review.createdAt}</span>
                </div>
                <h2 className="mt-4 text-2xl font-bold text-white">{review.reviewerName} on {review.targetName}</h2>
                <div className="mt-2 text-brand">{'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}</div>
                <p className="mt-4 text-white/70">{review.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
