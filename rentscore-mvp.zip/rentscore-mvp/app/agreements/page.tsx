import { PageHero } from '@/components/page-hero';

export default function AgreementsPage() {
  return (
    <>
      <PageHero
        eyebrow="AI agreements"
        title="Periodic tenancy agreement generator"
        description="Prompt-driven agreement builder for the post-Renters’ Rights Act market, designed to output editable text and downloadable PDFs."
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-6 py-10 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="card p-6">
          <h2 className="text-2xl font-bold text-white">Agreement inputs</h2>
          <form className="mt-5 space-y-4">
            <input className="input" placeholder="Tenant names" />
            <input className="input" placeholder="Landlord / company name" />
            <input className="input" placeholder="Property address" />
            <div className="grid gap-4 md:grid-cols-2">
              <input className="input" placeholder="Monthly rent" />
              <input className="input" placeholder="Deposit amount" />
            </div>
            <textarea className="input min-h-32" placeholder="Special clauses, pets, furnishings, maintenance responsibilities" />
            <button type="button" className="button-primary">Generate draft agreement</button>
          </form>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">AI output preview</h2>
            <div className="badge">Editable</div>
          </div>
          <div className="mt-5 space-y-4 rounded-3xl border border-white/10 bg-white/5 p-5 text-sm leading-7 text-white/75">
            <p><strong className="text-white">Periodic Tenancy Agreement</strong></p>
            <p>This agreement is made between the Landlord and Tenant for the occupation of the Property on a periodic basis, subject to the terms below and any statutory rights that apply in England.</p>
            <p><strong className="text-white">Rent:</strong> £2,350 payable monthly in advance on the 1st of each month.</p>
            <p><strong className="text-white">Repairs and reporting:</strong> The Tenant will report faults through the RentScore maintenance portal. The Landlord will acknowledge urgent safety issues within the stated property SLA.</p>
            <p><strong className="text-white">Reviews and trust data:</strong> The parties agree that verified tenancy performance data may be retained within RentScore in line with the platform privacy notice.</p>
            <p className="text-white/55">In production this page should call an LLM endpoint with template grounding, moderation and legal review prompts before export.</p>
          </div>
        </div>
      </section>
    </>
  );
}
